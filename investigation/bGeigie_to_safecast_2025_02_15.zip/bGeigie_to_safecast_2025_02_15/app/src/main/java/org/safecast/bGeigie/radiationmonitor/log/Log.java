package org.safecast.bGeigie.radiationmonitor.log;

import java.util.ArrayList;

public final class Log extends ArrayList<LogEntry> {
}
