package org.safecast.bGeigie.radiationmonitor.main;

import static org.safecast.bGeigie.radiationmonitor.main.Monitor.dateTimeFormatter;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.IOException;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.TimeZone;
import java.util.function.BiConsumer;

class DebugHandler {
	private boolean debugEnable = false;
	private static final String DEBUG_DIRECTORY = "/SafeCast/DebugLogs";
	private static final String TAG = "DebugHandler";
	private final ContentResolver contentResolver;
	private final ToastManager toastManager;
	private Uri uri;

	public DebugHandler(Context context, ToastManager toastManager) {
		this.toastManager = toastManager;
		this.contentResolver = context.getContentResolver();
	}

	public enum Level {
		ERROR("Error", android.util.Log::e),
		WARNING("Warning", android.util.Log::w),
		INFO("Info", android.util.Log::i),
		DEBUG("Debug", android.util.Log::d);

		private final String name;
		private final BiConsumer<String, String> logger;

		Level(String name, BiConsumer<String, String> logger) {
			this.name = name;
			this.logger = logger;
		}
	}

	public void debug(Level level, String tag, String message) {
		if (!debugEnable) {
			return;
		}

		level.logger.accept(tag, message);
		writeMessageToFile(level, tag, message);
	}

	public void toggleDebug() {
		debugEnable = !debugEnable;
		android.util.Log.i("DebugHandler", "debugEnable is now " + debugEnable);
		if (!debugEnable) {
			toastManager.showToast("Debugging is now disabled.", Color.YELLOW);
			return;
		}

		toastManager.showToast("Debugging is now enabled.", Color.YELLOW);
		try {
			openMessageFile();
		} catch (IOException e) {
			android.util.Log.e(TAG, "Error opening message file: " + e.getMessage());
		}
	}

	private void openMessageFile() throws IOException {

		// Scoped Storage method for Android 10+
		String fileName = "debug_" + LocalDateTime.now().format(dateTimeFormatter) + ".log";
		ContentValues values = new ContentValues();
		values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
		values.put(MediaStore.Downloads.MIME_TYPE, "application/x-safecast-log");
		values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + DEBUG_DIRECTORY);

		uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
		if (uri == null) {
			android.util.Log.e(TAG, "Exception: Failed to create new MediaStore record.");
			throw new IOException("Failed to create new MediaStore record.");
		} else {
			debug(Level.INFO, TAG, "New MediaStore record with URI: " + uri);
		}
		writeDeviceHeader();
	}

	private void writeMessageToFile(Level level, String tag, String message) {
		if (uri == null) {
			android.util.Log.e(TAG, "Cannot write to file: URI is null");
			return;
		}

		try (OutputStream output = contentResolver.openOutputStream(uri, "wa")) {
			if (output == null) {
				android.util.Log.e(TAG, "Failed to open output stream for writing");
				return;
			}

			String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
			String debugMessage = String.format("%s - %-7s - %-25s: %s\n", timestamp, level.name, tag, message);
			output.write(debugMessage.getBytes());
		} catch (IOException e) {
			android.util.Log.e(TAG, "Error writing to file: " + e.getMessage());
		}
	}

	private void writeDeviceHeader() {
		writeMessageToFile(Level.INFO, TAG, "---------------------------------------------------");
		writeMessageToFile(Level.INFO, TAG, "Device Information:");
		writeMessageToFile(Level.INFO, TAG, "---------------------------------------------------");
		writeMessageToFile(Level.INFO, TAG, "Manufacturer: " + Build.MANUFACTURER);
		writeMessageToFile(Level.INFO, TAG, "Model: " + Build.MODEL);
		writeMessageToFile(Level.INFO, TAG, "Device: " + Build.DEVICE);
		writeMessageToFile(Level.INFO, TAG, "Product: " + Build.PRODUCT);
		writeMessageToFile(Level.INFO, TAG, "Hardware: " + Build.HARDWARE);
		writeMessageToFile(Level.INFO, TAG, "Board: " + Build.BOARD);
		writeMessageToFile(Level.INFO, TAG, "Bootloader: " + Build.BOOTLOADER);
		writeMessageToFile(Level.INFO, TAG, "Host: " + Build.HOST);
		writeMessageToFile(Level.INFO, TAG, "ID: " + Build.ID);
		writeMessageToFile(Level.INFO, TAG, "Tags: " + Build.TAGS);
		writeMessageToFile(Level.INFO, TAG, "Type: " + Build.TYPE);
		writeMessageToFile(Level.INFO, TAG, "User: " + Build.USER);
		writeMessageToFile(Level.INFO, TAG, "---------------------------------------------------");
		writeMessageToFile(Level.INFO, TAG, "Software Information:");
		writeMessageToFile(Level.INFO, TAG, "---------------------------------------------------");
		writeMessageToFile(Level.INFO, TAG, "Release: " + Build.VERSION.RELEASE);
		writeMessageToFile(Level.INFO, TAG, "SDK: " + Build.VERSION.SDK_INT);
		writeMessageToFile(Level.INFO, TAG, "Incremental: " + Build.VERSION.INCREMENTAL);
		writeMessageToFile(Level.INFO, TAG, "Codename: " + Build.VERSION.CODENAME);
		writeMessageToFile(Level.INFO, TAG, "---------------------------------------------------");
		writeMessageToFile(Level.INFO, TAG, "Other Information:");
		writeMessageToFile(Level.INFO, TAG, "---------------------------------------------------");
		writeMessageToFile(Level.INFO, TAG, "Locale: " + Locale.getDefault().toString());
		writeMessageToFile(Level.INFO, TAG, "Timezone: " + TimeZone.getDefault().getDisplayName());
		writeMessageToFile(Level.INFO, TAG, "---------------------------------------------------");
	}
}