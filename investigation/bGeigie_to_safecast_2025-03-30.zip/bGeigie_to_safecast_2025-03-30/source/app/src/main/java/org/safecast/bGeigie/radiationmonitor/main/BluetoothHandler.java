package org.safecast.bGeigie.radiationmonitor.main;

import static android.app.Activity.RESULT_OK;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.BluetoothStatusCodes;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import androidx.activity.result.contract.ActivityResultContracts;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

class BluetoothHandler {
	// UUID necessary to communicate with BLE device
	private static final UUID SERVICE_DATA_UUID = UUID.fromString("EF080D8C-C3BE-41FF-BD3F-05A5F4795D7F");
	private static final UUID CHARACTERISTIC_READ_UUID = UUID.fromString("A1E8F5B1-696B-4E4C-87C6-69DFE0B0093B");
	@SuppressWarnings("unused")
	private static final UUID CHARACTERISTIC_WRITE_UUID = UUID.fromString("1494440E-9A58-4CC0-81E4-DDEA7F74F623");
	private static final UUID CLIENT_CHARACTERISTIC_CONFIG = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

	// Tag for debugging
	private static final String TAG = "BluetoothHandler";

	// Necessary to communicate with Monitor
	private final Monitor monitor;
	private final ToastManager toastManager;

	// Bluetooth stuff
	private final BluetoothAdapter adapter;
	private BluetoothGatt bluetoothGatt;
	private final Set<DataCallback> callbacks = new HashSet<>();
	private final Set<OnDisconnect> onDisconnects = new HashSet<>();
	private boolean isDiscovering;

	// Timeout and retry logic
	private static final long TIMEOUT_THRESHOLD = 60000; //  Timeout for lost connection
	private final Handler timeoutHandler = new Handler(Looper.getMainLooper());

	public BluetoothHandler(Monitor monitor, ToastManager toastManager) {
		this.monitor = monitor;
		this.toastManager = toastManager;
		this.adapter = ((BluetoothManager) monitor.getSystemService(Context.BLUETOOTH_SERVICE)).getAdapter();
		if (adapter == null) {
			monitor.d(TAG, "Bluetooth is not supported on this device.");
			toastManager.showToast("Bluetooth is not supported on this device.", Color.RED);
			return;
		}

		if (!this.adapter.isEnabled()) {
			monitor.registerForActivityResult(
					new ActivityResultContracts.StartActivityForResult(),
					result -> {
						if (result.getResultCode() == RESULT_OK) {
							monitor.d(TAG, "Bluetooth enabled by user.");
						} else {
							monitor.d(TAG, "Bluetooth enabling denied by user.");
						}
					}
			).launch(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE));
		}
	}

	private final Runnable timeoutRunnable = new Runnable() {
		// If data is not received within this time -> assume lost connection -> disconnect.
		@Override
		public void run() {
			monitor.w(TAG, "No data received for " + TIMEOUT_THRESHOLD + "ms. Assuming connection is lost. Disconnecting.");
			toastManager.showToast("Bluetooth connection timeout. Disconnecting.", Color.RED);
			disconnect();
		}
	};

	public interface OnDeviceFound {
		void accept(BluetoothDevice device);
	}

	@SuppressLint("MissingPermission")
	public void discover(OnDeviceFound callback) {
		if (isDiscovering) stopDiscover();

		isDiscovering = true;
		monitor.registerReceiver(new BroadcastReceiver() {
			@Override
			public void onReceive(Context context, Intent intent) {
				String action = intent.getAction();
				if (!BluetoothDevice.ACTION_FOUND.equals(action)) {
					return;
				}
				BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
				if (device != null) {
					callback.accept(device);
				}
			}
		}, new IntentFilter(BluetoothDevice.ACTION_FOUND));
		adapter.startDiscovery();
	}

	@SuppressLint("MissingPermission")
	public void stopDiscover() {
		if (isDiscovering) {
			adapter.cancelDiscovery();
			isDiscovering = false;
			monitor.d(TAG, "stopDiscover called.");
		}
	}

	@SuppressLint("MissingPermission")
	public void setConnectedDevice(BluetoothDevice device) {
		if (isConnected()) disconnect();
		stopDiscover();

		monitor.d(TAG, "Attempting to connect to device:");
		monitor.d(TAG, "	Name: " + device.getName());
		monitor.d(TAG, "	Address: " + device.getAddress());

		this.bluetoothGatt = device.connectGatt(monitor, true, new BluetoothGattCallback() {
			private static final int MAX_RETRIES = 20;
			private static final int RETRY_DELAY = 2000;
			private static final Handler RETRY_HANDLER = new Handler(Looper.getMainLooper());
			private int retryCount = 0;
			private boolean isReconnecting = false;
			private Runnable retryRunnable;

			@Override
			public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
				monitor.runOnUiThread(() -> monitor.setBluetoothConnected(false));
				switch (newState) {
					case BluetoothProfile.STATE_CONNECTED -> {
						monitor.i(TAG, "onConnectionStateChange: Connected");
						toastManager.showToast("Bluetooth is connected.", Color.GREEN);
						retryCount = 0;
						isReconnecting = false;
						RETRY_HANDLER.removeCallbacks(retryRunnable);
						gatt.discoverServices();
						monitor.runOnUiThread(() -> monitor.setBluetoothConnected(true));
						// Start timeout when connected
						timeoutHandler.postDelayed(timeoutRunnable, TIMEOUT_THRESHOLD);
					}

					case BluetoothProfile.STATE_DISCONNECTED -> {
						ClickSoundGenerator.getInstance().setClickRate(0);
						monitor.w(TAG, "onConnectionStateChange: Disconnected");
						toastManager.showToast("Bluetooth is disconnected.\nAttempting to reconnect...", Color.YELLOW);
						// Stop timeout monitoring
						timeoutHandler.removeCallbacks(timeoutRunnable);
						if (isReconnecting) {
							return;
						}
						isReconnecting = true;
						retryRunnable = () -> {
							if (retryCount < MAX_RETRIES && isReconnecting) {
								retryCount++;
								monitor.w(TAG, "Attempting to reconnect (attempt " + retryCount + " of " + MAX_RETRIES + ") in " + RETRY_DELAY + "ms.");
								if (!gatt.connect()) {
									monitor.e(TAG, "Failed to start reconnection.");
								} else {
									monitor.d(TAG, "Started reconnection attempt successfully.");
								}
								// Always re-post the retryRunnable
								RETRY_HANDLER.postDelayed(retryRunnable, RETRY_DELAY);
							} else {
								if (retryCount >= MAX_RETRIES) {
									monitor.e(TAG, "Failed to reconnect after " + MAX_RETRIES + " attempts.");
									toastManager.showToast("Bluetooth is disconnected.\nFailed to reconnect.", Color.RED);
								}
								retryCount = 0;
								isReconnecting = false;
								// Notify the user or take other action
								disconnect();
							}
						};
						RETRY_HANDLER.postDelayed(retryRunnable, RETRY_DELAY);
					}
				}
			}

			@Override
			public void onServicesDiscovered(BluetoothGatt gatt, int status) {
				if (status != BluetoothGatt.GATT_SUCCESS) {
					monitor.e(TAG, "Failed to discover GATT services.");
					return;
				}
				for (BluetoothGattService service : gatt.getServices()) {
					monitor.d(TAG, "Service UUID: " + service.getUuid());
					for (BluetoothGattCharacteristic characteristic : service.getCharacteristics()) {
						monitor.d(TAG, "Characteristic UUID: " + characteristic.getUuid());
					}
				}

				monitor.d(TAG, "GATT services discovered.");

				// Get the service by UUID
				BluetoothGattService service = gatt.getService(SERVICE_DATA_UUID);
				if (service == null) {
					monitor.e(TAG, "Service with UUID " + SERVICE_DATA_UUID + " not found.");
					return;
				}

				// Get the read characteristic by UUID
				BluetoothGattCharacteristic readCharacteristic = service.getCharacteristic(CHARACTERISTIC_READ_UUID);
				if (readCharacteristic == null) {
					monitor.e(TAG, "Read characteristic not found.");
					return;
				}

				// Start timeout when services are discovered
				timeoutHandler.postDelayed(timeoutRunnable, TIMEOUT_THRESHOLD);

				// Enable notifications for the read characteristic
				boolean success = gatt.setCharacteristicNotification(readCharacteristic, true);
				if (!success) {
					monitor.e(TAG, "Failed to enable notifications for read characteristic.");
					return;
				} else {
					monitor.d(TAG, "Notifications enabled for read characteristic.");
				}

				// Get the descriptor for the characteristic and enable notifications
				BluetoothGattDescriptor descriptor = readCharacteristic.getDescriptor(CLIENT_CHARACTERISTIC_CONFIG);
				if (descriptor == null) {
					monitor.e(TAG, "Descriptor for read characteristic not found.");
					return;
				} else {
					monitor.d(TAG, "Descriptor for read characteristic found.");
				}

				if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) { // API 33+
					success = gatt.writeDescriptor(descriptor, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)
							== BluetoothStatusCodes.SUCCESS;
					monitor.d(TAG, "API33+: Successfully wrote descriptor for read characteristic.");
				} else { // API 30+
					descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
					success = gatt.writeDescriptor(descriptor);
					monitor.d(TAG, "API30+: Successfully wrote descriptor for read characteristic.");
				}
				//success = gatt.writeDescriptor(descriptor, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE) == BluetoothStatusCodes.SUCCESS;
				if (!success) {
					monitor.e(TAG, "Failed to write descriptor for read characteristic.");
				}
			}

			@Override
			public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, byte[] value) {
				// API 33+
				//monitor.i(TAG, "onCharacteristicChanged called (API 33+).");
				onCharacteristicChanged0(gatt, characteristic, value);
			}

			@Override
			public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
				// API 18+
				//monitor.i(TAG, "onCharacteristicChanged called (API 18+).");
				onCharacteristicChanged0(gatt, characteristic, characteristic.getValue());
			}

			private void onCharacteristicChanged0(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, byte[] value) {
				// Get the raw byte array data from the characteristic
				String data = new String(value);  // Convert byte data to a string (if appropriate)

				// Reset timeout every time new data is received
				timeoutHandler.removeCallbacks(timeoutRunnable);
				timeoutHandler.postDelayed(timeoutRunnable, TIMEOUT_THRESHOLD);

				// Pass the data to all registered callbacks
				for (DataCallback callback : callbacks) {
					callback.accept(data);
				}
			}
		});
	}

	public interface DataCallback {
		void accept(String data);
	}

	public void onDataRead(DataCallback callback) {
		this.callbacks.add(callback);
	}

	@SuppressLint("MissingPermission")
	public boolean isConnected() {
		return this.bluetoothGatt != null;
	}

	public interface OnDisconnect extends Runnable {
	}

	public void onDisconnect(OnDisconnect callback) {
		this.onDisconnects.add(callback);
	}

	@SuppressLint("MissingPermission")
	public void disconnect() {
		monitor.d(TAG, "disconnect called.");
		toastManager.showToast("Bluetooth Device disconnected.", Color.RED);

		if (bluetoothGatt == null) {
			monitor.e(TAG, "bluetoothGatt is null.");
			return;
		}

		bluetoothGatt.disconnect();
		bluetoothGatt.close();
		bluetoothGatt = null;
		// Stop timeout monitoring
		timeoutHandler.removeCallbacks(timeoutRunnable);
		onDisconnects.forEach(OnDisconnect::run);

		monitor.d(TAG, "Disconnected from GATT server");
	}
}
